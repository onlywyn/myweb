.. _changelog:

+++++++++
Changelog
+++++++++

.. miscnews:: ../build/NEWS
