import sqlite3

con = sqlite3.connect("mydb")
